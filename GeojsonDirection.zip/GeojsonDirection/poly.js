var positionVertex=[];
var waypts_mtlsheloc=[];
var markers=[];
function initMap() {
    const map = new google.maps.Map(document.getElementById("map"), {
      zoom: 16,
      center: { lat: 10.761123, lng: 106.682655 },
    });
    const directionsService = new google.maps.DirectionsService();
    const directionsRenderer = new google.maps.DirectionsRenderer({
      draggable: true,
      map,
      panel: document.getElementById("right-panel"),
    });
    directionsRenderer.addListener("directions_changed", () => {
      computeTotalDistance(directionsRenderer.getDirections());
    });

    google.maps.event.addListener(map, "click", (event) => {
        addMarker(event.latLng, map);
        arr=JSON.stringify(event.latLng);
        var obj = new Object();
        obj['lat'] = event.latLng.lat();
        obj['lng'] = event.latLng.lng();
        positionVertex.push(obj);
        waypts_mtlsheloc.push({
                location: obj,
                stopover: false
        }) 
    });
    
    document.getElementById("getTrace").addEventListener("click",()=>displayRoute(
      positionVertex[0],
      positionVertex[0],
      directionsService,
      directionsRenderer
    ))
    
  }
  
  function displayRoute(origin, destination, service, display) {
    service.route(
      {
        origin: origin,
        destination: destination,
        waypoints: waypts_mtlsheloc,
        travelMode: google.maps.TravelMode.DRIVING,
        avoidTolls: true,
      },
      (result, status) => {
        if (status === "OK") {
          display.setDirections(result);
        } else {
          alert("Could not display directions due to: " + status);
        }
      }
    );
  }
  
  function computeTotalDistance(result) {
    let total = 0;
    const myroute = result.routes[0];
  
    for (let i = 0; i < myroute.legs.length; i++) {
      total += myroute.legs[i].distance.value;
    }
    total = total / 1000;
    document.getElementById("total").innerHTML = total + " km";
  }

  function addMarker(location, map) {
    // Add the marker at the clicked location, and add the next-available label
    // from the array of alphabetical characters.
    let marker=new google.maps.Marker({
        position: location,
        //label: labels[labelIndex++ % labels.length],
        animation: google.maps.Animation.DROP,
        map: map,
    });   
    markers.push(marker);
    }